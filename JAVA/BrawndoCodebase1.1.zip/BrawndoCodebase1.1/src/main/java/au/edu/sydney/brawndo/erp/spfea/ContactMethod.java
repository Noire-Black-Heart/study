package au.edu.sydney.brawndo.erp.spfea;

public enum ContactMethod {
    CARRIER_PIGEON,
    EMAIL,
    MAIL,
    MERCHANDISER,
    PHONECALL,
    SMS
}
