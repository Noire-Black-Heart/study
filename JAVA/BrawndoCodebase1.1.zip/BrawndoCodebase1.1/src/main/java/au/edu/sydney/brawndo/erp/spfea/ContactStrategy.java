package au.edu.sydney.brawndo.erp.spfea;

/**
 * Strategy interface
 */
public interface ContactStrategy {
    boolean doSend(ContactBean bean);
}
