
public class LastBlockPrinter implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
