import java.util.Vector;
import java.util.*;
import java.nio.file.*;
import java.io.*;

public class ServerInfoList {

    Vector<ServerInfo> serverInfos;

    public ServerInfoList() {
        serverInfos = new Vector<>();
    }

    public void initialiseFromFile(String filename) {
        // implement your code here
        
        Path filePath = Paths.get(filename);
        ArrayList<ServerInfo> tempStore = new ArrayList<ServerInfo>(100);
        int size = 0;
        
        try {
            Scanner scanner = new Scanner(filePath);
            
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                
                if (line.equals("")) {
                    continue;
                }
                
                String[] splitLine = line.split("=");
                
                if (splitLine.length == 2) {
                    String leftSide = splitLine[0];
                    
                    String[] leftSideSplit = leftSide.split("\\.");
                    if (leftSideSplit.length == 2) {
                        
                        if (leftSideSplit[1].equals("num") && leftSideSplit[0].equals("servers")) {
                            size = Integer.parseInt(splitLine[1]);
                            
                        } else {
                            int serverNumber = Integer.parseInt(leftSideSplit[0].replace("server", ""));
                            
                            if (serverNumber < 0) {
                                continue;
                            }
                            
                            try {
                                tempStore.get(serverNumber);
                            } catch (IndexOutOfBoundsException e) {
                                tempStore.add(serverNumber, new ServerInfo(null, -1));
                            }
                            
                            if (leftSideSplit[1].equals("port")) {
                                int portNumber = Integer.parseInt(splitLine[1]);
                                
                                if (portNumber >= 1024 && portNumber <= 65535) {
                                    tempStore.get(serverNumber).setPort(portNumber);
                                }
                            } else if (leftSideSplit[1].equals("host")) {
                                tempStore.get(serverNumber).setHost(splitLine[1]);
                            }
                        }
                    }
                }
            }
            
            serverInfos.setSize(size);
            
            for (int x = 0; x < size; x++) {
                try {
                    if (tempStore.get(x) == null) {
                        serverInfos.set(x, null);
                    } else if (tempStore.get(x).getHost() != null && tempStore.get(x).getPort() != -1) {
                        serverInfos.set(x, tempStore.get(x));
                    } else {
                        serverInfos.set(x, null);
                    }
                } catch ( IndexOutOfBoundsException e ) {
                    serverInfos.add(x, null);
                }
            }
            
        } catch(ArrayIndexOutOfBoundsException e) {
            // e.printStackTrace();
        } catch (FileNotFoundException e) {
           // e.printStackTrace();
        } catch (IOException e) {
            // e.printStackTrace();
        }
    }

    public Vector<ServerInfo> getServerInfos() {
        return serverInfos;
    }

    public void setServerInfos(Vector<ServerInfo> serverInfos) {
        this.serverInfos = serverInfos;
    }

    public boolean addServerInfo(ServerInfo newServerInfo) { 
        // implement your code here
        serverInfos.add(newServerInfo);
        return true;
    }

    public boolean updateServerInfo(int index, ServerInfo newServerInfo) { 
        // implement your code here
        try {
            serverInfos.set(index, newServerInfo);
        } catch (ArrayIndexOutOfBoundsException e) {
            // System.out.print("Array index out of range: " + index + "\n");
            return false;
        }
        
        return true;
    }
    
    public boolean removeServerInfo(int index) { 
        // implement your code here
        try {
            serverInfos.set(index, null);
        } catch (ArrayIndexOutOfBoundsException e) {
            // System.out.print("Array index out of range: " + index + "\n");
            return false;
        }
        
        return true;
    }

    public boolean clearServerInfo() { 
        // implement your code here
        
        for (int x = serverInfos.size()-1; x >= 0; x--) {
            if (serverInfos.get(x) == null) {
                serverInfos.remove(x);
            }
        }
        
        return true;
    }

    public String toString() {
        String s = "";
        for (int i = 0; i < serverInfos.size(); i++) {
            if (serverInfos.get(i) != null) {
                s += "Server" + i + ": " + serverInfos.get(i).getHost() + " " + serverInfos.get(i).getPort() + "\n";
            }
        }
        return s;
    }

    // implement any helper method here if you need any
    
    public ServerInfo getServerInfo(int index) {
        return serverInfos.get(index);
    }
    
    public int getSize(){
        return serverInfos.size();
    }
    
    
}