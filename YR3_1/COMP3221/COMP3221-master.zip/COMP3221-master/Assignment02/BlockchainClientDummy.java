import java.util.Scanner;
import java.util.*;
import java.net.*;
import java.io.*;

public class BlockchainClientDummy {

    public static void main(String[] args) {

        if (args.length != 1) {
            System.out.print("No server initialisation file specified\n");
            return;
        }
        String configFileName = args[0];

        ServerInfoList pl = new ServerInfoList();
        pl.initialiseFromFile(configFileName);

        Scanner sc = new Scanner(System.in);

        while (true) {
            String message = sc.nextLine();
            // implement your code here
            
            if (message.equals("ls")) {
                System.out.print(pl.toString() + "\n");
            }
            
            else if (message.startsWith("ad")) {
                String[] splitMessage = message.split("\\|");
                
                if (splitMessage.length == 3) {
                    
                    if (isInteger(splitMessage[2])) {
                        Integer portNumber = Integer.parseInt(splitMessage[2]);
                        
                        if (portNumber >= 1024 && portNumber <= 65535) {
                            pl.addServerInfo(new ServerInfo(splitMessage[1], portNumber));
                            System.out.print("Succeeded\n\n");
                        }
                        
                        else {
                           System.out.print("Failed\n\n"); 
                        }
                    } else {
                        System.out.print("Failed\n\n");
                    }
                } else {
                    System.out.print("Failed\n\n");
                }
            }
            
             else if (message.startsWith("rm")) {
                String[] splitMessage = message.split("\\|");
                
                if (splitMessage.length == 2) {
                    
                    if (isInteger(splitMessage[1])) {
                        if (pl.removeServerInfo(Integer.parseInt(splitMessage[1]))) {
                            System.out.print("Succeeded\n\n");
                        } else {
                            System.out.print("Failed\n\n");
                        }
                        
                    } else {
                        System.out.print("Failed\n\n");
                    }
                } else {
                    System.out.print("Failed\n\n");
                }
            }
            
            else if (message.startsWith("up")) {
                String[] splitMessage = message.split("\\|");
                
                if (splitMessage.length == 4) {
                    if (isInteger(splitMessage[3]) && isInteger(splitMessage[1])) {
                        Integer portNumber = Integer.parseInt(splitMessage[3]);
                        
                        if (portNumber >= 1024 && portNumber <= 65535) {
                            pl.updateServerInfo(Integer.parseInt(splitMessage[1]), new ServerInfo(splitMessage[2], portNumber));
                            System.out.print("Succeeded\n\n");
                        }
                        
                        else {
                           System.out.print("Failed\n\n"); 
                        }
                    } else {
                        System.out.print("Failed\n\n");
                    }
                    
                } else {
                    System.out.print("Failed\n\n");
                }
            }
            
            else if (message.equals("cl")) {
                pl.clearServerInfo();
                System.out.print("Succeeded\n\n");
            }
            
            // Message Format: broadcast <message>
            else if (message.startsWith("broadcast")) {
                String[] splitMessage = message.split(" ");
                
                if (splitMessage.length == 2) {
                    broadcast(pl, splitMessage[1]);
                }
            }
            
            // Message Format: multicast <message> <serverNumber>|<ServerNumber>|...
            else if (message.startsWith("multicast")) {
                String[] splitMessage = message.split(" ");
                
                if (splitMessage.length == 3) {
                    String[] rightSide = splitMessage[2].split("\\|");
                    ArrayList<Integer> serverNumbers = new ArrayList<Integer>(rightSide.length - 1);
                    
                    for (int x = 0; x < rightSide.length; x++) {
                        serverNumbers.add(Integer.parseInt(rightSide[x]));
                    }
                    
                    multicast(pl, serverNumbers, splitMessage[0]);
                }
            }
            
            // Message Format: unicast <message> <serverNumber>
            else if (message.startsWith("unicast")) {
                String[] splitMessage = message.split(" ");
                
                if (splitMessage.length == 3) {
                    int serverNumber = Integer.parseInt(splitMessage[2]);
                    
                    unicast(serverNumber, pl.getServerInfo(serverNumber), splitMessage[1]);
                }
            }
            
            else if (message.startsWith("tx")) {
                String[] splitMessage = message.split("\\|");
                
                if (splitMessage.length == 3) {
                    broadcast(pl, message);
                }
            }
            
            else if (message.startsWith("pb")) {
                if (message.equals("pb")) {
                    broadcast(pl, "pb");
                } else {
                    String[] splitMessage = message.split("\\|");
                    ArrayList<Integer> serverNumbers = new ArrayList<Integer>(splitMessage.length - 1);
                    Boolean allNumbers = true;
                    
                    for (int x = 1; x < splitMessage.length; x++) {
                        if (isInteger(splitMessage[x])) {
                            serverNumbers.add(Integer.parseInt(splitMessage[x]));
                        } else {
                            allNumbers = false;
                            System.out.println("Invalid Server Number(s)");
                            break;
                        }
                    }
                    
                    if (allNumbers) {
                        multicast(pl, serverNumbers, "pb");
                    }
                }
                
                
            }
            
            else if (message.equals("sd")) {
                break;
            }
            
            else {
                System.out.print("Unknown Command\n\n");
            }
            
        }
        
    }

    public static void unicast (int serverNumber, ServerInfo p, String message) {
        // implement your code here
        
        newThread(serverNumber, p, message);
        
    }

    public static void broadcast (ServerInfoList pl, String message) {
        // implement your code here
        
        for (int x = 0; x < pl.getSize(); x++) {
            ServerInfo info = pl.getServerInfo(x);
            if (info != null) {
                newThread(x, info, message);
            }
        }
        
    }

    public static void multicast (ServerInfoList serverInfoList, ArrayList<Integer> serverIndices, String message) {
        // implement your code here
        
        for (int x = 0; x < serverInfoList.getSize(); x++) {
            if (serverIndices.contains(x)) {
                ServerInfo info = serverInfoList.getServerInfo(x);
                if (info != null) {
                    newThread(x, info, message);
                }
            }
        }
        
    }

    // implement any helper method here if you need any
    
    private static boolean isInteger(String number) {
        try {
            Integer index = Integer.parseInt(number);
            return true;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private static void newThread(int serverNumber, ServerInfo p, String message) {
        BlockchainClientRunnable runnable = new BlockchainClientRunnable(serverNumber, p.getHost(), p.getPort(), message);
        Thread thread = new Thread(runnable);
        
        thread.start();
        
        long endTimeMillis = System.currentTimeMillis() + 2000;
        while (thread.isAlive()) {
            if (System.currentTimeMillis() > endTimeMillis) {
                try {
                    thread.join(1);
                    System.out.print("Server is not available\n\n");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }
}