import java.net.Socket;
import java.io.*;

public class BlockchainServerRunnable implements Runnable{

    private Socket clientSocket;
    private Blockchain blockchain;
    private Boolean closeConnection = false;

    public BlockchainServerRunnable(Socket clientSocket, Blockchain blockchain) {
        // implement your code here
        this.clientSocket = clientSocket;
        this.blockchain = blockchain;
    }

    public void run() {
        // implement your code here
        
        OutputStream outputStream = null;
        InputStream inputStream = null;
        
        while (true) {
            try {
                
                // Opening the socket and creating IO streams
                outputStream = clientSocket.getOutputStream();
                inputStream = clientSocket.getInputStream();
                
                // Retrieving requests from the user
            
                serverHandler(inputStream, outputStream);
                
                // Closing the socket if requested
                if (closeConnection == true) {
                    outputStream.close();
                    inputStream.close();
                    clientSocket.close();
                    break;
                }
                
            
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }
        
    }
    
    // implement any helper method here if you need any
    
    public void serverHandler(InputStream clientInputStream, OutputStream clientOutputStream) {
        BufferedReader inputReader = new BufferedReader(
            new InputStreamReader(clientInputStream));
        PrintWriter outWriter = new PrintWriter(clientOutputStream, true);
        
        String current = "";
        
        // Reading the input from the user
        try {
            while((current = inputReader.readLine()) != null){
        
                // If action is to add to the block chain
                if (current.startsWith("tx")) {
                    Boolean addTransactionValue = blockchain.addTransaction(current);
                    
                    // Rejecting or accepting the transaction
                    if (addTransactionValue == false) {
                        outWriter.print("Rejected\n\n");
                    } else {
                        outWriter.print("Accepted\n\n");
                    }
                
                // Printing the pool for the user	
                } else if (current.equals("pb")) {
                    outWriter.print(blockchain.toString() + "\n");
                
                // Quitting the client program	
                } else if (current.equals("cc")) {
                    closeConnection = true;
                    break;
                    
                } else if (!current.equals("")) {
                    outWriter.print("Error\n\n");
                }
                
                outWriter.flush();
            }
        
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
}
