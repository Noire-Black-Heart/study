import java.net.*;
import java.io.*;

public class BlockchainServer {

    public static void main(String[] args) {

        if (args.length == 0) {
            return;
        }

        String arguments = String.join(" ", args);
        int portNumber;
        
        try {
            portNumber = Integer.parseInt(arguments);
        } catch (NumberFormatException e) {
            System.out.print("For input string: \"" + arguments + "\"\n");
            return;
        }
        
        Blockchain blockchain = new Blockchain();


        PeriodicCommitRunnable pcr = new PeriodicCommitRunnable(blockchain);
        Thread pct = new Thread(pcr);
        pct.start();

        // implement your code here
        // https://stackoverflow.com/questions/36981462/convert-single-threaded-server-into-multi-threaded-in-java
        ServerSocket serverSocket = null;
        Socket socket = null;
        
        try {
            serverSocket = new ServerSocket(portNumber);
        } catch (IllegalArgumentException e) {
            System.out.print("Port value out of range: " + portNumber + "\n");
            return;
        } catch (IOException e) {
            // e.printStackTrace();
        }
        
        while (pcr.getRunning()) {
            try {
                socket = serverSocket.accept();
            } catch (BindException e) {
                // e.printStackTrace();
                return;
            } catch (ConnectException e) {
                System.out.print("Could not open socket on port " + portNumber + "\n");
                return;
            } catch (NullPointerException e) {
                return;
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            new Thread(new BlockchainServerRunnable(socket, blockchain)).start();
            
        }
        
        // WHAT IS THIS???? [BELOW]
        // http://www.henryxi.com/java-thread-join-example
        pcr.setRunning(false);
        try {
            pct.join();
        } catch (InterruptedException e) {
            // e.printStackTrace();
        }
    }

    // implement any helper method here if you need any
}
