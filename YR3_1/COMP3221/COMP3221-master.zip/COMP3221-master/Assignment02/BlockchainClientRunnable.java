import java.net.*;
import java.io.*;

public class BlockchainClientRunnable implements Runnable {

    private String reply;
    private int serverNumber;
    private String serverName;
    private int portNumber;
    private String message;

    public BlockchainClientRunnable(int serverNumber, String serverName, int portNumber, String message) {
        this.reply = "Server" + serverNumber + ": " + serverName + " " + portNumber + "\n"; // header string
        this.serverNumber = serverNumber;
        this.serverName = serverName;
        this.portNumber = portNumber;
        this.message = message;
    }

    public void run() {
        // implement your code here
        
        OutputStream outputStream = null;
        InputStream inputStream = null;
        
        System.out.print(reply);
        
        try {
            Socket socket = new Socket(serverName, portNumber);
            outputStream = socket.getOutputStream();
            inputStream = socket.getInputStream();
            
            
            BufferedReader inputReader = new BufferedReader(new InputStreamReader(inputStream));
            PrintWriter outWriter = new PrintWriter(outputStream, true);
            
            outWriter.println(message);
            
            try {
                String line = "";
                
                // Printing response back from the server
                while ((line = inputReader.readLine()) != null) {
                    reply += line + "\n"; 
                    System.out.print(line + "\n");
                    
                    if(!inputReader.ready()){
                        break;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            socket.close();
            
        } catch (ConnectException e) {
            System.out.print("Server is not available\n\n");
            reply += "Server is not available\n\n";
        } catch (IOException e) {
            
        }
        
    }

    public String getReply() {
        return reply;
    }

    // implement any helper method here if you need any
}