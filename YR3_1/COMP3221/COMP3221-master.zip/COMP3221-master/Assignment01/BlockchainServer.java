import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class BlockchainServer {
	
	private Blockchain blockchain;
	
	private static Boolean closeConnection = false;
	
	public BlockchainServer() { blockchain = new Blockchain(); }
	
	// getters and setters
	public void setBlockchain(Blockchain blockchain) { this.blockchain = blockchain; }
	public Blockchain getBlockchain() { return blockchain; }
	
	public static void main(String[] args) { 
		if (args.length != 1) {
			return;
		}
		int portNumber = Integer.parseInt(args[0]);
		BlockchainServer bcs = new BlockchainServer();
		
		// implement your code here.
		
		ServerSocket serverSocket = null;
		Socket socket = null;
		OutputStream outputStream = null;
		InputStream inputStream = null;
		
		// Creating a new socket
		try {
			serverSocket = new ServerSocket(portNumber);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		while (true) {
			try {
				
				// Opening the socket and creating IO streams
				socket = serverSocket.accept();
				outputStream = socket.getOutputStream();
				inputStream = socket.getInputStream();
				
				// Retrieving requests from the user
			
				bcs.serverHandler(inputStream, outputStream);
				
				// Closing the socket if requested
				if (closeConnection == true) {
					outputStream.close();
					inputStream.close();
					socket.close();
					closeConnection = false;
				}
				
			
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void serverHandler(InputStream clientInputStream, OutputStream clientOutputStream) {
		BufferedReader inputReader = new BufferedReader(
			new InputStreamReader(clientInputStream));
		PrintWriter outWriter = new PrintWriter(clientOutputStream, true);
		
		// implement your code here.
		
		String current = "";
		
		// Reading the input from the user
		try {
			while((current = inputReader.readLine()) != null){
		
				// If action is to add to the block chain
				if (current.startsWith("tx")) {
					int addTransactionValue = this.getBlockchain().addTransaction(current);
					
					// Rejecting or accepting the transaction
					if (addTransactionValue == 0) {
						outWriter.print("Rejected\n\n");
					} else {
						outWriter.print("Accepted\n\n");
					}
				
				// Printing the pool for the user	
				} else if (current.equals("pb")) {
					outWriter.print(this.getBlockchain().toString() + "\n");
				
				// Quitting the client program	
				} else if (current.equals("cc")) {
					closeConnection = true;
					break;
					
				} else if (!current.equals("")) {
					outWriter.print("Error\n\n");
				}
				
				outWriter.flush();
			}
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	// implement helper functions here if you need any.
}