import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;
import java.net.Socket;
import java.io.IOException;

public class BlockchainClient {
	
	public static void main(String[] args) {
		
		if (args.length != 2) {
			return;
		}
		String serverName = args[0];
		int portNumber = Integer.parseInt(args[1]);
		BlockchainClient bcc = new BlockchainClient();
		
		// implement your code here.
		
		Socket socket = null;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		
		try {
			// Opening the socket and creating IO streams
			socket = new Socket(serverName, portNumber);
			outputStream = socket.getOutputStream();
			inputStream = socket.getInputStream();
			
			// Running the client side
			bcc.clientHandler(inputStream, outputStream);
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void clientHandler(InputStream serverInputStream, OutputStream serverOutputStream) {
		BufferedReader inputReader = new BufferedReader(
			new InputStreamReader(serverInputStream));
		PrintWriter outWriter = new PrintWriter(serverOutputStream, true);
		
		Scanner sc = new Scanner(System.in);
		while (sc.hasNextLine()) {
			// implement your code here
			
			// Getting input from the user
			String input = sc.nextLine();
			// Sending input to server
			outWriter.println(input);
			
			// If user wants to quit the connection
			if (input.equals("cc")) {
				break;
			}
			
			try {
				String line = "";
				
				// Printing response back from the server
				while ((line = inputReader.readLine()) != null) {
					System.out.println(line);
					
					if(!inputReader.ready()){
						break;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	// implement helper functions here if you need any
}