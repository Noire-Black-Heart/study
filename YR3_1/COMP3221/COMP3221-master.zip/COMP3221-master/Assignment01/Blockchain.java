import java.util.ArrayList;

public class Blockchain {

	private Block head;
	private ArrayList<Transaction> pool;
	private int length;

	private final int poolLimit = 3;

	public Blockchain() {
		pool = new ArrayList<>();
		length = 0;
	}

	// getters and setters
	public Block getHead() { return head; }
	public ArrayList<Transaction> getPool() { return pool; }
	public int getLength() { return length; }
	public void setHead(Block head) { this.head = head; }
	public void setPool(ArrayList<Transaction> pool) { this.pool = pool; }
	public void setLength(int length) { this.length = length; }

	// add a transaction
	public int addTransaction(String txString) {
		// implement you code here.
				
		String[] txStringParts = txString.split("\\|");
		
		// Checks if the character "|" is in txString and txString is in the correct format
		if (txStringParts.length != 3) {
			return 0;
		}
		
		// Checks to see if the header is correct
		if (!txStringParts[0].equals("tx")) {
			return 0;
		}
		
		// Checks to see if the sender's id is in the correct format
		if (!txStringParts[1].matches("[a-z]{4}[0-9]{4}")) {
			return 0;
		}
		
		// Checks to see if the message is greater than 70
		if (txStringParts[2].length() > 70) {
			return 0;
		}
		
		// Turning the input to a Transaction
		Transaction trans = new Transaction();
		trans.setSender(txStringParts[1]);
		trans.setContent(txStringParts[2]);
		
		// Adding the new transaction to the pool
		pool.add(trans);
		
		// If the pool is full
		if (pool.size() == poolLimit) {
			
			// Committing pool to the block chain
			Block newBlock= new Block();
			newBlock.setTransactions(pool);
			newBlock.setPreviousBlock(head);
			
			// If first block
			if (head == null) {
				byte[] zero = new byte[32];
				zero[0] = 0;
				newBlock.setPreviousHash(zero);
			} else {
				newBlock.setPreviousHash(head.calculateHash());
			}
						
			// Changing the head
			head = newBlock;
			
			// Increasing the blockchain and clearing the pool
			length += 1;
			pool = new ArrayList<>();
			return 2;
			
		} else {
			return 1;
		}
	}

	public String toString() {
		String cutOffRule = new String(new char[81]).replace("\0", "-") + "\n";
		String poolString = "";
		for (Transaction tx : pool) {
			poolString += tx.toString();
		}

		String blockString = "";
		Block bl = head;
		while (bl != null) {
			blockString += bl.toString();
			bl = bl.getPreviousBlock();
		}

		return "Pool:\n"
			+ cutOffRule
			+ poolString
			+ cutOffRule
			+ blockString;
	}

	// implement helper functions here if you need any.	
}