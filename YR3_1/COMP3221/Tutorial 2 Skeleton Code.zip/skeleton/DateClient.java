import java.net.*;
import java.io.*;

public class DateClient {
	public static void main(String[] args) {
		try {
            // TODO

			// read the date from the socket
			String line;
			while ((line = bin.readLine()) != null)
				System.out.println(line);

            // TODO
		} catch (IOException ioe) {
			System.err.println(ioe);
		}
	}
}