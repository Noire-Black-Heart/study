package au.edu.sydney.soft3202.tutorials.week10.mvc.view;

import au.edu.sydney.soft3202.tutorials.week10.mvc.model.Counter;

public class CounterView {
    private Counter model;

    public CounterView(Counter model) {

        this.model = model;
    }

    public void launch() {

    }
}
