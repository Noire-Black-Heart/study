package au.edu.sydney.soft3202.tutorials.week7.quiz.withInheritance;

public abstract class SlowElectricVehicle extends SlowVehicle {
    protected String  getEngineOutput() {
        return "There is a quiet hum.";
    }
}
