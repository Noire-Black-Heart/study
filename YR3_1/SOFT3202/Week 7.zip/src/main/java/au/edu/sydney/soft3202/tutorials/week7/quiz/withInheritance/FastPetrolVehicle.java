package au.edu.sydney.soft3202.tutorials.week7.quiz.withInheritance;

public abstract class FastPetrolVehicle extends FastVehicle {
    protected String  getEngineOutput() {
        return "There are petrol fumes spewing out the back.";
    }
}
