package au.edu.sydney.soft3202.tutorials.week7.quiz.withBridge;

public interface Vehicle {
    void drive();
}
