package au.edu.sydney.soft3202.tutorials.week7.quiz.withoutBridgeOrInheritance;

public interface Vehicle {
    void drive();
}
