package au.edu.sydney.soft3202.tutorials.week7.chain;

public class ExampleMainClass {

    public static void main(String[] args) {
        //
    }
}
