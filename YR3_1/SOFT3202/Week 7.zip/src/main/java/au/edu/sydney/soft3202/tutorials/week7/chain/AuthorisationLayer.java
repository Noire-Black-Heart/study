package au.edu.sydney.soft3202.tutorials.week7.chain;

public interface AuthorisationLayer {

    boolean authenticate(Authorisation authorisation);
}
