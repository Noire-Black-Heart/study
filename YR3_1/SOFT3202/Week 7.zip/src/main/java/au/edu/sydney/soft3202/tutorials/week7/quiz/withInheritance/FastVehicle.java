package au.edu.sydney.soft3202.tutorials.week7.quiz.withInheritance;

public abstract class FastVehicle implements Vehicle{
    protected String  getSpeedOutput() {
        return "Going really fast!";
    }
}
