package au.edu.sydney.soft3202.tutorials.week7.quiz.withBridge;

public class ElectricEngine implements VehicleEngine {
    @Override
    public String getEngineOutput() {
        return "There is a quiet hum.";
    }
}
