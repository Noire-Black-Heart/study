package au.edu.sydney.soft3202.tutorials.week7.quiz.withBridge;

public class PetrolEngine implements VehicleEngine {
    @Override
    public String getEngineOutput() {
        return "There are petrol fumes spewing out the back.";
    }
}
