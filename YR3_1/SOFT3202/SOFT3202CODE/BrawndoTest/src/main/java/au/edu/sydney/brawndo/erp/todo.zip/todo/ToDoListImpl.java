package au.edu.sydney.brawndo.erp.todo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import au.edu.sydney.brawndo.erp.todo.Task.Field;

public class ToDoListImpl implements ToDoList{

	//private List<Task> taskList = new ArrayList<Task>();
	private Map<Integer, Task> taskMap = new HashMap<Integer, Task>();
	private boolean hasFixedID = false;
	private int generatedIDcount = 0;
	
	@Override
	public Task add(Integer id, LocalDateTime dateTime, String location, String description)
			throws IllegalArgumentException, IllegalStateException {
		
		// check: if null is added behind fixed ID
		if(hasFixedID && id == null) {
			throw new IllegalStateException();
		}
		
		//check: if fixed ID overlap with existing ID
		if(taskMap.containsKey(id)) {
			throw new IllegalArgumentException();
		}
		
		//note the list has fixed id given
		hasFixedID = true;
		
		//if id is null, generate a new id, also remove the fixed id given note
		if(id == null) {
			hasFixedID = false;
			while(taskMap.containsKey(generatedIDcount)) {
				generatedIDcount ++;
				id = generatedIDcount;
			}
		}
		
		
		Task oof = new TaskImpl(id, dateTime, location, description);
		
		taskMap.put(id, oof);
		
		return oof;
	}

	@Override
	public boolean remove(int id) {
		// if the id is not present
		if(!taskMap.containsKey(id)) {
			return false;
		}
		
		//if the id is present
		taskMap.remove(id);
		
		
		return true;
	}

	@Override
	public Task findOne(int id) {
		// TODO Auto-generated method stub
		if(taskMap.containsKey(id)) {
			return taskMap.get(id);
		}
		
		return null;
	}

	@Override
	public List<Task> findAll() {
		// TODO Auto-generated method stub
		List<Task> taskList = new ArrayList<Task>();
		for(Task task : taskMap.values()) {
			taskList.add(task);
		}
		
		return taskList;
	}

	@Override
	public List<Task> findAll(boolean completed) {
		// TODO Auto-generated method stub
		List<Task> taskList = new ArrayList<Task>();
		for(Task task : taskMap.values()) {
			if(task.isCompleted() == completed) {
			taskList.add(task);
			}
		}
		return taskList;
	}

	@Override
	public List<Task> findAll(LocalDateTime from, LocalDateTime to, Boolean completed) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		List<Task> taskList = new ArrayList<Task>();
		for(Task task : taskMap.values()) {
			if(task.isCompleted() == completed && task.getDateTime().isAfter(from) && task.getDateTime().isBefore(to)) {
			taskList.add(task);
			}
		}
		return taskList;
	}

	@Override
	public List<Task> findAll(Map<Field, String> params, LocalDateTime from, LocalDateTime to, Boolean completed,
			boolean andSearch) throws IllegalArgumentException {
		
		List<Task> taskList = new ArrayList<Task>();
		
		// if and search
		if(andSearch == true) {
			
			for(Task task : taskMap.values()) {
			//	taskList.add(task);
				if(from == null) {
					if(to == null) {
						if(completed == null) {
							if(params == null) {
								//go back
							}else {
								for(Map.Entry<Field, String> entry : params.entrySet()) {
									if(entry.getKey() == Field.DESCRIPTION) {
										if(task.getDescription() != entry.getValue()) {
											taskList.remove(task);
										}
									}
									else if(entry.getKey() == Field.LOCATION) {
										if(task.getLocation() != entry.getValue()) {
											taskList.remove(task);
										}
									}
								}
							}
						}
					}else {//to is not null
						if(!task.getDateTime().isBefore(to)) {
							taskList.remove(task);
						}
						if(completed == null) {
							if(params == null) {
								//go back
							}else {
								for(Map.Entry<Field, String> entry : params.entrySet()) {
									if(entry.getKey() == Field.DESCRIPTION) {
										if(task.getDescription() != entry.getValue()) {
											taskList.remove(task);
										}
									}
									else if(entry.getKey() == Field.LOCATION) {
										if(task.getLocation() != entry.getValue()) {
											taskList.remove(task);
										}
									}
								}
							}
						}
					}
				}else {//from is not null
					if(to == null) {
						
					}else {//from, to is not null
						
					}
				}
			}
			
			
			
			
			
		}
		
		
		
		
		
		
		
		
		for(Field field : params.keySet()) {
			if
		}
		
		
		
		return null;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		taskMap.clear();
		hasFixedID = false;
		generatedIDcount = 0;
		
	}

	
	
}